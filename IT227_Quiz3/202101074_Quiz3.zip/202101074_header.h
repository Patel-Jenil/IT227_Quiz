int is_digit(char c);
int is_prime(int n);
