I'm Jenil Patel 202101074
Please use this folder to execute my shell scripts for best outcomes of 5th and 6th Question.
Keeping my other files intact.
Thanks.